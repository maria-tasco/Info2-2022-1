#ifndef CATEGORIAS_GASTOS_H
#define CATEGORIAS_GASTOS_H


void mostrar_matriz(char **matriz, int nC);
char **registrar_categoria(char **categorias, unsigned *nC);
char **reservar_memoria_Dinamica_incial(unsigned int *nC);

#endif // CATEGORIAS_GASTOS_H
