#ifndef CATEGORIAS_H
#define CATEGORIAS_H
void mostrar_matriz(char **matriz, int nC);
unsigned short menu();
char **registrar_categoria(char **categorias, unsigned *nC);
char **reservar_memoria_Dinamica_incial(unsigned int *nC);
#endif // CATEGORIAS_H
